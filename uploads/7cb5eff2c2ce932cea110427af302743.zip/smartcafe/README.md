# ☕ Smart Café — Site Web

> Design inspiré de Google Stitch · Mobile-first · HTML/CSS/JS pur

---

## 📁 Structure du projet

```
smartcafe/
├── index.html          ← Page d'accueil
├── menu.html           ← Menu (café, thé, jus, boulangerie, desserts)
├── reservation.html    ← Formulaire de réservation
├── events.html         ← Événements à venir
├── contact.html        ← Contact + réseaux sociaux
├── css/
│   └── style.css       ← Tout le design system (variables, composants)
├── js/
│   └── app.js          ← Navigation, data menu, fonctions JS
└── README.md           ← Ce fichier
```

---

## 🎨 Design System

### Couleurs
| Variable           | Valeur    | Usage                        |
|--------------------|-----------|------------------------------|
| `--primary`        | `#d47311` | Orange — boutons, accents     |
| `--accent-green`   | `#2d4a3e` | Vert foncé — titres, logo     |
| `--bg-light`       | `#f8f7f6` | Fond principal                |
| `--cream`          | `#f3ede7` | Fonds cartes, inputs          |
| `--warm-gray`      | `#9a734c` | Texte secondaire              |

### Typographie
- **Police principale** : `Plus Jakarta Sans` (Google Fonts)
- **Icônes** : `Material Symbols Outlined` (Google)

---

## 📄 Pages

### 1. `index.html` — Accueil
- Hero avec image + CTA "Réserver" / "Voir le menu"
- Accès rapide Menu / Réserver / Événements
- À la une (highlights du jour)
- Grille des 4 espaces (Bibliothèque, Coworking, Étudiants, Réunions)
- Info rapide (horaires, adresse)

### 2. `menu.html` — Menu
- Onglets : Café / Thé / Jus / Boulangerie / Desserts
- Barre de recherche en temps réel
- Affichage liste ou grille selon la section
- Bouton "Ajouter" avec feedback toast

### 3. `reservation.html` — Réservation
- Formulaire complet : nom, email, date, heure, personnes, espace, demandes
- Validation avant soumission
- Informations pratiques (horaires, adresse, tél)

### 4. `events.html` — Événements
- Filtres par catégorie : Tous / Séminaires / Meetups / Club Lecture / Workshop
- Cards avec image, badge catégorie, date, lieu, description
- Bouton "S'inscrire" avec confirmation toast

### 5. `contact.html` — Contact
- Carte visuelle adresse
- Infos : adresse, téléphone, email, horaires
- Liens réseaux sociaux (Instagram, TikTok, Facebook)
- Formulaire de message

---

## 🚀 Comment utiliser

### Option 1 — Ouvrir directement
Double-cliquer sur `index.html` dans votre navigateur.

### Option 2 — Serveur local (recommandé)
```bash
# Python
python -m http.server 3000

# Node.js (npx)
npx serve .

# VS Code
Installer l'extension "Live Server" et cliquer sur "Go Live"
```
Puis ouvrir : `http://localhost:3000`

---

## ✏️ Personnalisation

### Changer les prix / produits
Modifier le tableau `MENU_DATA` dans `js/app.js` :
```js
{ price: '22 Dh', name: 'Vanilla Oat Latte', desc: '...', img: 'URL_IMAGE' }
```

### Changer les couleurs
Modifier les variables dans `css/style.css` :
```css
:root {
  --primary: #d47311;       /* Votre couleur principale */
  --accent-green: #2d4a3e;  /* Votre couleur secondaire */
}
```

### Ajouter un événement
Dans `events.html`, dupliquer un bloc `.event-card-wrap` et modifier le contenu.

### Changer l'adresse / téléphone
Rechercher `+212 6XX` et `Quartier Maarif` dans tous les fichiers HTML et remplacer.

---

## 📱 Responsive
Le site est conçu **mobile-first** (max 480px) mais s'affiche correctement sur desktop avec un effet de carte centrée.

---

## 🛠️ Technologies
- HTML5 sémantique
- CSS3 (variables, flexbox, grid, animations)
- JavaScript vanilla (ES6+)
- Google Fonts (Plus Jakarta Sans)
- Material Symbols (Google Icons)
- Images : Unsplash (gratuites)

---

*Smart Café © 2026 · Casablanca, Maroc*
