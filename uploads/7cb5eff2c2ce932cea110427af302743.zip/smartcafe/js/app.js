/* ═══════════════════════════════════════════
   SMART CAFÉ — Global JavaScript
   Navigation + Data + Utilities
═══════════════════════════════════════════ */

// ── Toast ──────────────────────────────────
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

// ── Page Navigation ───────────────────────
function navigateTo(href) {
  window.location.href = href;
}

// ── Active nav link ────────────────────────
function setActiveNav() {
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.page === page) btn.classList.add('active');
  });
}

// ── Reservation submit ─────────────────────
function submitReservation() {
  const name  = document.getElementById('r-name')?.value.trim();
  const email = document.getElementById('r-email')?.value.trim();
  const date  = document.getElementById('r-date')?.value;
  const time  = document.getElementById('r-time')?.value;
  if (!name || !email || !date || !time) {
    showToast('❗ Veuillez remplir tous les champs');
    return;
  }
  showToast(`✅ Réservation confirmée pour ${name} !`);
  ['r-name','r-email','r-date','r-time','r-note'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = id === 'r-people' ? el.value : '';
  });
}

// ── Contact submit ─────────────────────────
function submitContact() {
  const name = document.getElementById('c-name')?.value.trim();
  const msg  = document.getElementById('c-msg')?.value.trim();
  if (!name || !msg) { showToast('❗ Merci de remplir les champs'); return; }
  showToast(`✅ Message envoyé, ${name} !`);
  ['c-name','c-email','c-msg'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

// ── Events filter ──────────────────────────
function filterEvents(btn, cat) {
  document.querySelectorAll('.event-filter-btn').forEach(b => {
    b.className = b.className.replace('chip-active', 'chip-inactive');
  });
  btn.className = btn.className.replace('chip-inactive', 'chip-active');
  document.querySelectorAll('.event-card-wrap').forEach(card => {
    card.style.display = (cat === 'all' || card.dataset.cat === cat) ? 'block' : 'none';
  });
}

// ── Menu Data ──────────────────────────────
const MENU_DATA = {
  cafe: {
    sections: [
      {
        title: 'Signature Brews',
        type: 'list',
        items: [
          { price: '22 Dh', name: 'Vanilla Oat Latte',     desc: 'Espresso crémeux, lait d\'avoine, vanille maison',   img: 'https://images.unsplash.com/photo-1561047029-3000c68339ca?w=300&q=80' },
          { price: '28 Dh', name: 'Cappuccino Classique',   desc: 'Espresso, mousse de lait soyeuse, cacao',           img: 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=300&q=80' },
        ]
      },
      {
        title: 'Fresh & Cold',
        type: 'grid',
        items: [
          { price: '15 Dh', name: 'Espresso',      img: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=300&q=80' },
          { price: '25 Dh', name: 'Latte Noisette', img: 'https://images.unsplash.com/photo-1561047029-3000c68339ca?w=300&q=80' },
        ]
      }
    ]
  },
  the: {
    sections: [{
      title: 'Thés & Infusions', type: 'list',
      items: [
        { price: '12 Dh', name: 'Thé à la menthe',  desc: 'Thé vert, menthe fraîche, miel',          img: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=300&q=80' },
        { price: '15 Dh', name: 'Thé Oolong',       desc: 'Semi-oxydé, notes florales et fruitées',  img: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=300&q=80' },
        { price: '18 Dh', name: 'Chai Latte',        desc: 'Épices chaudes, lait chaud, cannelle',    img: 'https://images.unsplash.com/photo-1572657651379-2ad83b3c56e5?w=300&q=80' },
      ]
    }]
  },
  jus: {
    sections: [{
      title: 'Fresh & Cold', type: 'grid',
      items: [
        { price: '18 Dh', name: 'Orange frais',   img: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=300&q=80' },
        { price: '25 Dh', name: 'Smoothie Mangue', img: 'https://images.unsplash.com/photo-1571091655789-405eb7a3a3a8?w=300&q=80' },
        { price: '22 Dh', name: 'Green Detox',    img: 'https://images.unsplash.com/photo-1610970881699-44a5587cabec?w=300&q=80' },
        { price: '20 Dh', name: 'Limonade fraîche', img: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=300&q=80' },
      ]
    }]
  },
  boulangerie: {
    sections: [{
      title: 'Boulangerie', type: 'list',
      items: [
        { price: '20 Dh', name: 'Croissant beurre', desc: 'Feuilleté maison, beurre AOP, cuit le matin', img: 'https://images.unsplash.com/photo-1608198093002-ad4e005484ec?w=300&q=80' },
        { price: '35 Dh', name: 'Sandwich poulet',  desc: 'Poulet grillé, légumes frais, sauce maison',  img: 'https://images.unsplash.com/photo-1553909489-cd47e0907980?w=300&q=80' },
        { price: '18 Dh', name: 'Pain aux raisins',  desc: 'Viennoiserie classique, raisins secs',         img: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc7c?w=300&q=80' },
      ]
    }]
  },
  desserts: {
    sections: [{
      title: 'Desserts', type: 'list',
      items: [
        { price: '30 Dh', name: 'Cheesecake vanille', desc: 'Fromage frais, coulis fruits rouges, base sablée', img: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=300&q=80' },
        { price: '22 Dh', name: 'Brownie chocolat',   desc: 'Fondant, noix, chocolat noir 70%',                img: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=300&q=80' },
        { price: '18 Dh', name: 'Crème caramel',       desc: 'Recette traditionnelle maison',                  img: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=300&q=80' },
      ]
    }]
  }
};

// ── Render Menu ────────────────────────────
let currentTab = 'cafe';

function renderMenuContent(tab, filter = '') {
  currentTab = tab;
  const container = document.getElementById('menu-content');
  if (!container) return;
  const data = MENU_DATA[tab];
  if (!data) return;

  let html = '';
  data.sections.forEach(section => {
    const filtered = section.items.filter(item =>
      item.name.toLowerCase().includes(filter.toLowerCase()) ||
      (item.desc || '').toLowerCase().includes(filter.toLowerCase())
    );
    if (!filtered.length) return;

    html += `<div class="mb-4"><h3 class="section-heading px-4 pb-3">${section.title}</h3>`;

    if (section.type === 'grid') {
      html += `<div class="grid-2 px-4">`;
      filtered.forEach(item => {
        html += `
          <div class="menu-grid-card">
            <div class="menu-grid-img" style="background-image:url('${item.img}')"></div>
            <div class="menu-grid-info">
              <div class="menu-grid-name">${item.name}</div>
              <div class="menu-grid-price">${item.price}</div>
              <button class="btn-add-full" onclick="showToast('${item.name} ajouté 🛒')">
                <span class="material-symbols-outlined" style="font-size:1rem">add</span> Ajouter
              </button>
            </div>
          </div>`;
      });
      html += `</div>`;
    } else {
      html += `<div class="px-4 flex flex-col gap-3">`;
      filtered.forEach(item => {
        html += `
          <div class="menu-item-card">
            <div style="flex:1">
              <div class="menu-item-price">${item.price}</div>
              <div class="menu-item-name">${item.name}</div>
              <div class="menu-item-desc">${item.desc || ''}</div>
              <button class="btn-add" onclick="showToast('${item.name} ajouté 🛒')">
                <span class="material-symbols-outlined" style="font-size:0.9rem">add</span> Ajouter
              </button>
            </div>
            <div class="menu-item-thumb" style="background-image:url('${item.img}')"></div>
          </div>`;
      });
      html += `</div>`;
    }
    html += `</div>`;
  });

  container.innerHTML = html || '<p style="text-align:center;color:#94a3b8;padding:3rem 1rem;font-size:0.9rem">Aucun résultat trouvé.</p>';
}

function switchTab(btn, tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('menu-search').value = '';
  renderMenuContent(tab);
}

function searchMenu() {
  renderMenuContent(currentTab, document.getElementById('menu-search').value);
}

// ── DOM Ready ──────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setActiveNav();

  // Min date for reservation
  const dateInput = document.getElementById('r-date');
  if (dateInput) dateInput.min = new Date().toISOString().split('T')[0];

  // Init menu page
  if (document.getElementById('menu-content')) renderMenuContent('cafe');

  // Page fade-in
  document.querySelector('.app-container')?.classList.add('page-fade');
});
